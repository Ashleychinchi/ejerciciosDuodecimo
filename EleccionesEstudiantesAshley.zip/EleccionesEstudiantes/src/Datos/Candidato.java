package datos;

import datos.VotosRangoEdad.Edad;
import datos.VotosRangoEdad.Genero;

// Candidato de la urna de elecciones.
public class Candidato{
    // Enumeraciones
    // Enumeraciones para el medio de influencia.
    public enum Medio {
        // Representa el medio de influencia Internet.
        INTERNET,
        // Representa el medio de influencia radio.
        RADIO,
        // Representa el medio de influencia televisiï¿½n.
        TELEVISION
    }

    // Constantes
    // Representa el costo de un voto influenciado por Internet.
    public final static double COSTO_INTERNET = 100;

    // Representa el costo de un voto influenciado por radio.
    public final static double COSTO_RADIO = 500;

    // Representa el costo de un voto influenciado por televisiÃ³n.
    public final static double COSTO_TELEVISION = 1000;

    // Atributos
    // Nombre del candidato.
    private String nombre;
    // Apellido del candidato.
    private String apellido;
    // Partido polÃ­tico del candidato.
    private String partidoPolitico;
    // Edad del candidato.
    private int edad;
    // Costo de campaï¿½a del candidato.
    private double costoCampanha;
    // Nï¿½mero que identifica al candidato.
    private int numero;
    // Votos en el rango de edad joven: entre 18 y 34 aï¿½os.
    private VotosRangoEdad votosRango1;
    // Votos en el rango de edad media: entre 35 y 54 aï¿½os.
    private VotosRangoEdad votosRango2;
    // Votos en el rango de edad mayor: desde 55 aï¿½os en adelante.
    private VotosRangoEdad votosRango3;

    // MÃ©todos
    // Crea el candidato con los valores dados por parÃ¡metro.
    // El nombre, apellido, partido polÃ­tico y edad fueron inicializados con los valores dados por parÃ¡metro.
    // El costo de campaÃ±a se inicializÃ³ en cero.
    // Los votos en un rango de edad fueron inicializados con los siguientes valores:
    // Rango1 - Edad: Joven. <br>
    // Rango2 - Edad: Media. <br>
    // Rango3 - Edad: Mayor.
    // @param pNombre Nombre del candidato. pNombre != null && pNombre != "".
    // @param pApellido Apellido del Candidato. pApellido != null && pApellido != "".
    // @param pPartidoPolitico Partido polï¿½tico del candidato. pPartidoPolitico != null && pPartidoPolitico != "".
    // @param pEdad Edad del candidato. pEdad > 0.
    // @param pNumero NÃºmero del candidato. pNumero > 0 && pNumero < 4.
    public Candidato( String pNombre, String pApellido, String pPartidoPolitico, int pEdad, int pNumero ){
        nombre = pNombre;
        apellido = pApellido;
        partidoPolitico = pPartidoPolitico;
        edad = pEdad;
        costoCampanha = 0;
        numero = pNumero;

        votosRango1 = new VotosRangoEdad( Edad.EDAD_JOVEN );
        votosRango2 = new VotosRangoEdad( Edad.EDAD_MEDIA );
        votosRango3 = new VotosRangoEdad( Edad.EDAD_MAYOR );
    }

    // Retorna el nombre del candidato.
    public String darNombre( ){
        return nombre;
    }

    // Retorna el apellido del candidato.
    public String darApellido( ){
        return apellido;
    }

    // Retorna el partido polï¿½tico del candidato.
    public String darPartidoPolitico( ){
        return partidoPolitico;
    }

    // Retorna la edad del candidato.
    public int darEdad( ){
        return edad;
    }

    // Retorna el costo de campaÃ±a del candidato.
    public double darCostoCampanha( ){
        return costoCampanha;
    }

    // Retorna el nÃºmero del candidato.
    public int darNumero( ){
        return numero;
    }

    // Retorna la cantidad total de votos del candidato.
    public int darCantidadTotalVotos( ) {
        return votosRango1.darCantidadTotalVotos( ) + votosRango2.darCantidadTotalVotos( ) + votosRango3.darCantidadTotalVotos( );
    }

    // Retorna la cantidad total de votos de gÃ©nero femenino.
    public int darTotalVotosGeneroFemenino( )    {
        return votosRango1.darCantidadFemenino( ) + votosRango2.darCantidadFemenino( ) + votosRango3.darCantidadFemenino( );
    }

    // Retorna la cantidad total de votos de gÃ©nero masculino.
    public int darTotalVotosGeneroMasculino( ){
        return votosRango1.darCantidadMasculino( ) + votosRango2.darCantidadMasculino( ) + votosRango3.darCantidadMasculino( );
    }

    // Retorna los votos del rango de edad 1.
    public VotosRangoEdad darVotosRango1( ){
        return votosRango1;
    }

    // Retorna los votos del rango de edad 2.
    public VotosRangoEdad darVotosRango2( ){
        return votosRango2;
    }

    // Retorna los votos del rango de edad 3.
    public VotosRangoEdad darVotosRango3( ){
        return votosRango3;
    }

    // Registra un voto en rango de edad para el gÃ©nero y medio de influencia dados por parÃ¡metro.
    // La cantidad de votos en el rango de edad y gÃ©nero dados aumentÃ³ en uno.
    // El costo de campaÃ±a aumentÃ³ segÃºn el medio de influencia dado por parÃ¡metro.
    // @param pEdad Rango de edad de la persona que registrÃ³ el voto. pEdad == EDAD_JOVEN || pEdad == EDAD_MEDIA || pEdad == EDAD_MAYOR.
    // @param pGenero GÃ©nero de la persona que registrÃ³ el voto. pGenero == MASCULINO || pGenero == FEMENINO.
    // @param pMedio Medio de influencia que influenciÃ³ el voto. pMedio == INTERNET || pMedio == RADIO || pMedio == TELEVISION.
    public void registrarVoto( Edad pEdad, Genero pGenero, Medio pMedio ) {
        switch( pEdad ) {
            case EDAD_JOVEN:
            {   votosRango1.registrarVoto( pGenero );
                break;
            }
            case EDAD_MEDIA:
            {   votosRango2.registrarVoto( pGenero );
                break;
            }
            case EDAD_MAYOR:
            {   votosRango3.registrarVoto( pGenero );
                break;
            }
        }

        switch( pMedio ) {
            case INTERNET:
            {   costoCampanha += COSTO_INTERNET;
                break;
            }
            case RADIO:
            {   costoCampanha += COSTO_RADIO;
                break;
            }
            case TELEVISION:
            {   costoCampanha += COSTO_TELEVISION;
                break;
            }
        }
    }

    // Reinicia la informaciÃ³n del candidato.
    // Los votos de los rangos 1, 2 y 3 fueron reiniciados.
    // El costo de campaï¿½a fue cambiado a 0.
    public void reiniciar( ){
        votosRango1.reiniciar( );
        votosRango2.reiniciar( );
        votosRango3.reiniciar( );
        costoCampanha = 0;
    }
}
