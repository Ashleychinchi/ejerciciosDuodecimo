package datos;
    // Votos de un rango de edad.
public class VotosRangoEdad {
    // Enumeradores para los rangos de edad.
    public enum Edad {
        // Representa el rango entre 18 y 34 aÃ±os.
        EDAD_JOVEN,
        // Representa el rango entre 35 y 54 aÃ±os.
        EDAD_MEDIA,
        // Representa el rango de 55 aÃ±os en adelante.
        EDAD_MAYOR
    }

    // Enumeradores para gÃ©nero.
    public enum Genero{
        // Representa el gÃ©nero masculino.
        MASCULINO,
        // Representa el gÃ©nero femenino.
        FEMENINO
    }

    // Atributos
    // Cantidad de votos de personas con gÃ©nero masculino.
    private int cantidadMasculino;
    // Cantidad de votos de personas con gÃ©nero femenino.
    private int cantidadFemenino;
    // Edad del rango.
    private final Edad edad;

    // Constructores
    // -----------------------------------------------------------------
    // Crea los votos en un rango de edad.
    // La cantidad de votos del gÃ©nero masculino fueron inicializados en 0.
    // La cantidad de votos del gÃ©nero femenino fueron inicializados en 0.
    // @param pEdad Rango de edad. pEdad pertenece a Edad.
    public VotosRangoEdad( Edad pEdad ){
        cantidadMasculino = 0;
        cantidadFemenino = 0;
        edad = pEdad;
    }

    // MÃ©todos
    // Retorna la cantidad de votos de personas con gÃ©nero masculino.
    public int darCantidadMasculino( ) {
        return cantidadMasculino;
    }

    // Retorna la cantidad de votos de personas con gÃ©nero femenino.
    public int darCantidadFemenino( ){
        return cantidadFemenino;
    }

    // Retorna la edad del rango.
    public Edad darEdad( ){
        return edad;
    }

    // Retorna la cantidad total de votos.
    public int darCantidadTotalVotos( ){
        int total = cantidadMasculino + cantidadFemenino;
        return total;
    }

    // Registra un voto al gÃ©nero dado por parÃ¡metro.
    // AumentÃ³ en uno la cantidad de votos de un gÃ©nero.
    // @param pGenero GÃ©nero al cual aumentar la cantidad de votos. pGenero == MASCULINO || pGenero == FEMENINO.
    public void registrarVoto( Genero pGenero ){
        switch( pGenero ){
            case MASCULINO:
            {   cantidadMasculino++;
                break;
            }
            case FEMENINO:
            {   cantidadFemenino++;
                break;
            }
        }
    }

    //Reinicia el conteo de votos.
    //La cantidad de votos masculinos y femeninos ahora son 0.
    public void reiniciar( ){
        cantidadMasculino = 0;
        cantidadFemenino = 0;
    }
}
