package datos;

import datos.Candidato.Medio;
import datos.VotosRangoEdad.Edad;
import datos.VotosRangoEdad.Genero;

// Urna de votaciÃ³n con tres candidatos.
public class Urna{
    // Atributos
    // Candidato nÃºmero 1 de la elecciones.
    private Candidato candidato1;
    // Candidato nÃºumero 2 de la elecciones.
    private Candidato candidato2;
    // Candidato nÃºumero 3 de la elecciones.
    private Candidato candidato3;
    private Candidato candidato4;

    // MÃ©todos
     // Inicializa los tres candidatos.
     // Candidato1 - Nombre: Andrea, Apellido: Combes, Partido polÃ­tico: Independiente, Edad: 27, NÃºmero: 1.
     // Candidato2 - Nombre: Felipe, Apellido: Pitti, Partido polÃ­tico: Revolucionario, Edad: 26, NÃºmero: 2.
     // Candidato3 - Nombre: Susanita, Apellido: Chirusi, Partido polÃ­tico: Tradicional, Edad: 26, NÃºmero: 3.
    public Urna( ){
        candidato1 = new Candidato( "Andrea", "Combes", "Independiente", 27, 1 );
        candidato2 = new Candidato( "Felipe", "Pitti", "Revolucionario", 26, 2 );
        candidato3 = new Candidato( "Susanita", "Chirusi", "Tradicional", 26, 3 );
        candidato4 = new Candidato( "Filipondio", "Flip", "Tradicional", 20, 4 );
    }

    // Retorna el candidato 1.
    public Candidato darCandidato1( ){
        return candidato1;
    }

    // Retorna el candidato 2.
    public Candidato darCandidato2( ){
        return candidato2;
    }
    
    // Retorna el candidato 3.
    public Candidato darCandidato3( ) {
        return candidato3;
    }
    
    // Retorna el candidato 4.
    public Candidato darCandidato4( ) {
        return candidato4;
    }


    // Busca el candidato con el nombre dado.
    // @param pNumero NÃºmero del candidato a buscar. pNumero > 0 && pNumero < 4.
    // @return El candidato con el nombre dado, null si no lo encuentra.
    public Candidato buscarCandidato( int pNumero ){
        Candidato buscado = null;

        if( candidato1.darNumero( ) == pNumero ) {
            buscado = candidato1;
        } else if( candidato2.darNumero( ) == pNumero ){
            buscado = candidato2;
        } else if( candidato3.darNumero( ) == pNumero ){
            buscado = candidato3;
        } else if( candidato4.darNumero( ) == pNumero ){
            buscado = candidato4;
        }
        return buscado;
    }

    // Retorna el total de votos de todos los candidatos.
    public int calcularTotalVotos( ){
        return candidato1.darCantidadTotalVotos( ) + candidato2.darCantidadTotalVotos( ) + candidato3.darCantidadTotalVotos( )+ candidato4.darCantidadTotalVotos( );
    }

    // Retorna el total de votos de todos los candidatos por votantes de gÃ©nero femenino.
    public int calcularTotalVotosGeneroFemenino( ) {
        return candidato1.darTotalVotosGeneroFemenino( ) + candidato2.darTotalVotosGeneroFemenino( ) + candidato3.darTotalVotosGeneroFemenino( )+ candidato4.darTotalVotosGeneroFemenino( );
    }

    // Retorna el total de votos de todos los candidatos por votantes de gÃ©nero masculino.
    public int calcularTotalVotosGeneroMasculino( ){
        return candidato1.darTotalVotosGeneroMasculino( ) + candidato2.darTotalVotosGeneroMasculino( ) + candidato3.darTotalVotosGeneroMasculino( )+ candidato4.darTotalVotosGeneroMasculino( );
    }

    // Retorna el total de votos en un rango de edad especÃ­fico.
    // @param pEdad Edad del rango. pEdad == EDAD_JOVEN || pEdad == EDAD_MEDIA || pEdad == EDAD_MAYOR.
    public int darTotalVotosRangoEdad( Edad pEdad ){
        int total = 0;
        switch( pEdad ) {
            case EDAD_JOVEN:
            {   total = candidato1.darVotosRango1( ).darCantidadTotalVotos( ) + candidato2.darVotosRango1( ).darCantidadTotalVotos( ) + candidato3.darVotosRango1( ).darCantidadTotalVotos( )+ candidato4.darVotosRango1( ).darCantidadTotalVotos( );
                break;
            }
            case EDAD_MEDIA:
            {   total = candidato1.darVotosRango2( ).darCantidadTotalVotos( ) + candidato2.darVotosRango2( ).darCantidadTotalVotos( ) + candidato3.darVotosRango2( ).darCantidadTotalVotos( )+ candidato4.darVotosRango2( ).darCantidadTotalVotos( );
                break;
            }
            case EDAD_MAYOR:
            {   total = candidato1.darVotosRango3( ).darCantidadTotalVotos( ) + candidato2.darVotosRango3( ).darCantidadTotalVotos( ) + candidato3.darVotosRango3( ).darCantidadTotalVotos( )+ candidato4.darVotosRango3( ).darCantidadTotalVotos( );
                break;
            }
        }
        return total;
    }

    // Calcula el costo promedio de campaÃ±a de los candidatos.
    public double calcularCostoPromedioCampanha( ) {
        double total = candidato1.darCostoCampanha( ) + candidato2.darCostoCampanha( ) + candidato3.darCostoCampanha( )+ candidato4.darCostoCampanha( );
        double promedio = total / 3;

        return promedio;
    }

    // Retorna el porcentaje de votos obtenidos por el candidato con el nombre dado por parÃ¡metro.
    // @param pNumero Nï¿½mero del candidato a buscar. pNumero > 0 && pNumero < 4.
    public double calcularPorcentajeVotosCandidato( int pNumero ){
        double numVotosCandidato = buscarCandidato( pNumero ).darCantidadTotalVotos( );
        double votosTotales = calcularTotalVotos( );
        double porcentaje = numVotosCandidato / votosTotales * 100;
        return porcentaje;
    }

    // Registra un voto al candidato con el nombre dado por parÃ¡metro.
    // Los votos del candidato aumentaron en uno en el rango y gï¿½nero dado. <br>
    // AumentÃ³ el costo de campaÃ±a del candidato.
    // @param pNumero NÃºmero del candidato a buscar. pNumero > 0 && pNumero < 4.
    // @param pEdad Rango de edad de la persona que registrÃ³ el voto. pEdad == EDAD_JOVEN || pEdad == EDAD_MEDIA || pEdad == EDAD_MAYOR.
    // @param pGenero GÃ©nero de la persona que registrÃ³ el voto. pGenero == MASCULINO || pGenero == FEMENINO.
    // @param pMedio Medio de influencia que influenciÃ³ el voto. pMedio == INTERNET || pMedio == RADIO || pMedio == TELEVISION.
    public void registrarVoto( int pNumero, Edad pEdad, Genero pGenero, Medio pMedio ) {
        Candidato buscado = buscarCandidato( pNumero );
        if( buscado != null ){
            buscado.registrarVoto( pEdad, pGenero, pMedio );
        }
    }

    // Reinicia los 3 candidatos.
    public void reiniciar( ) {
        candidato1.reiniciar( );
        candidato2.reiniciar( );
        candidato3.reiniciar( );
        candidato4.reiniciar( );
    }

    // Puntos de ExtensiÃ³n
    // MÃ©todo para la extensiÃ³n 1.
    public String metodo1( ){
        return "Respuesta 1";
    }

    // MÃ©todo para la extensiÃ³n 2.
    public String metodo2( ){
        return "Respuesta 2";
    }
}