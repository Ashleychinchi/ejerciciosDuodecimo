package interfaz;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.border.TitledBorder;

// Panel de manejo de opciones.
@SuppressWarnings("serial")
public class PanelOpciones extends JPanel implements ActionListener {
    // Constantes
    // Comando para las estadÃ­sticas.
    private static final String ESTADISTICAS = "ESTADISTICAS";
    // Comando para vaciar la urna.
    private static final String VACIAR_URNA = "VACIAR_URNA";
    // Comando para la opciÃ³n 1.
    private static final String OPCION_1 = "OPCION_1";
    // Comando para la opciÃ³n 2.
    private static final String OPCION_2 = "OPCION_2";

    // Atributos
    // Ventana principal de la aplicaciÃ³n.
    private InterfazElecciones principal;

    // Atributos de interfaz
    // BotÃ³n Estadisticas.
    private JButton btnEstadisticas;
    // BotÃ³n VaciarUrna.
    private JButton btnVaciarUrna;
    // BotÃ³n OpciÃ³n 1.
    private JButton btnOpcion1;
    // BotÃ³n OpciÃ³n 2.
    private JButton btnOpcion2;

    // Constructores
    // Constructor del panel.
    // @param pPrincipal Ventana principal de la aplicaciÃ³n.
    public PanelOpciones( InterfazElecciones pPrincipal ){
        principal = pPrincipal;

        setBorder( new TitledBorder( "Opciones" ) );
        setLayout( new GridLayout( 1, 4 ) );

        // BotÃ³n estadÃ­sticas
        btnEstadisticas = new JButton( "EstadÃ­sticas" );
        btnEstadisticas.setActionCommand( ESTADISTICAS );
        btnEstadisticas.addActionListener( this );
        add( btnEstadisticas );

        // BotÃ³n vaciar urna
        btnVaciarUrna = new JButton( "Vaciar urna" );
        btnVaciarUrna.setActionCommand( VACIAR_URNA );
        btnVaciarUrna.addActionListener( this );
        add( btnVaciarUrna );

        // BotÃ³n opciÃ³n 1
        btnOpcion1 = new JButton( "OpciÃ³n 1" );
        btnOpcion1.setActionCommand( OPCION_1 );
        btnOpcion1.addActionListener( this );
        add( btnOpcion1 );

        // BotÃ³n opciÃ³n 2
        btnOpcion2 = new JButton( "OpciÃ³n 2" );
        btnOpcion2.setActionCommand( OPCION_2 );
        btnOpcion2.addActionListener( this );
        add( btnOpcion2 );
    }

    // MÃ©todos
    // Manejo de los eventos de los botones.
    // @param pEvento Acciï¿½n que generï¿½ el evento. pEvento != null.
    @Override
    public void actionPerformed( ActionEvent pEvento ){
        if( OPCION_1.equals( pEvento.getActionCommand( ) ) ){
            principal.reqFuncOpcion1( );
        } else if( OPCION_2.equals( pEvento.getActionCommand( ) ) ) {
            principal.reqFuncOpcion2( );
        } else if( ESTADISTICAS.equals( pEvento.getActionCommand( ) ) ) {
            principal.mostrarDialogoEstadisticasTotales( );
        } else if( VACIAR_URNA.equals( pEvento.getActionCommand( ) ) ) {
            principal.reiniciarUrna( );
        }
    }
}
