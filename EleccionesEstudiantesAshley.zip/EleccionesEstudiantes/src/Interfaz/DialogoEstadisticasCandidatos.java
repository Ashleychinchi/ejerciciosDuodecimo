package interfaz;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.CategoryLabelPositions;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.data.category.DefaultCategoryDataset;

import datos.Candidato;

// DiÃ¡logo para mostrar las estadÃ­sticas de un candidato.
@SuppressWarnings("serial")
public class DialogoEstadisticasCandidatos extends JDialog implements ActionListener{
    // Atributos
    // Venta principal de la aplicaciÃ³n.
    private InterfazElecciones principal;

    // Constructores
    // Construye el diÃ¡logo e inicializa sus componentes
    // @param pPrincipal Es una referencia a la ventana principal de la interfaz. pPrincipal != null
    // @param pCandidato Candidato cuyas estadÃ­sticas se mostrarÃ¡n.
    public DialogoEstadisticasCandidatos( InterfazElecciones pPrincipal, Candidato pCandidato ){
        principal = pPrincipal;

        setTitle( "Votos por rango de edad candidato " + pCandidato.darNombre( ) + " " + pCandidato.darApellido( ) );
        setSize( 680, 455 );
        setDefaultCloseOperation( JDialog.DISPOSE_ON_CLOSE );

        setLayout( new BorderLayout( ) );

        DefaultCategoryDataset datosVotos = new DefaultCategoryDataset( );
        JFreeChart graficoVotos = crearGrafico( "Votos por rango de edad", datosVotos );

        ChartPanel panelVotos = new ChartPanel( graficoVotos );
        add( panelVotos, BorderLayout.CENTER );

        panelVotos.setBorder( new EmptyBorder( 5, 5, 5, 5 ) );
        datosVotos.setValue( pCandidato.darVotosRango1( ).darCantidadTotalVotos( ), "18 - 34 aÃ±os", "" );
        datosVotos.setValue( pCandidato.darVotosRango2( ).darCantidadTotalVotos( ), "35 - 54 aÃ±os", "" );
        datosVotos.setValue( pCandidato.darVotosRango3( ).darCantidadTotalVotos( ), "55 Ã³ mÃ¡s aÃ±os", "" );

        JPanel panelCentral = new JPanel( );
        add( panelCentral, BorderLayout.SOUTH );

        JButton btnAceptar = new JButton( "Aceptar" );
        btnAceptar.addActionListener( this );
        panelCentral.add( btnAceptar );

        setModal( true );
        setLocationRelativeTo( principal );
        setResizable( false );
    }

    // Crea y configura los atributos de la grÃ¡fica en barras.
    // @param pTitulo TÃ­tulo de la grÃ¡fica.
    private static JFreeChart crearGrafico( String pTitulo, DefaultCategoryDataset pDatos ){
        JFreeChart chart = ChartFactory.createBarChart( pTitulo, "Rango de edad", "Votos", pDatos, PlotOrientation.VERTICAL, true, true, false );
        chart.setBackgroundPaint( Color.white );

        CategoryPlot plot = chart.getCategoryPlot( );
        plot.setBackgroundPaint( Color.lightGray );
        plot.setDomainGridlinePaint( Color.white );
        plot.setRangeGridlinePaint( Color.white );

        NumberAxis rangeAxis = ( NumberAxis )plot.getRangeAxis( );
        rangeAxis.setStandardTickUnits( NumberAxis.createIntegerTickUnits( ) );

        BarRenderer renderer = ( BarRenderer )plot.getRenderer( );
        renderer.setDrawBarOutline( false );

        CategoryAxis domainAxis = plot.getDomainAxis( );
        domainAxis.setCategoryLabelPositions( CategoryLabelPositions.createUpRotationLabelPositions( Math.PI / 6.0 ) );
        return chart;
    }

    // MÃ©todo que se llama cuando de hace click sobre un botï¿½n.
    // @param pEvento Evento de click sobre un botÃ³n. pEvento != null.
    @Override
    public void actionPerformed( ActionEvent pEvento ){
        dispose( );
    }
}
