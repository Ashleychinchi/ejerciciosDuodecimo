package interfaz;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.text.DecimalFormat;
import java.text.NumberFormat;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

import datos.Candidato;
import datos.Candidato.Medio;
import datos.Urna;
import datos.VotosRangoEdad.Edad;
import datos.VotosRangoEdad.Genero;

// Ventana principal de la aplicaciÃ³n.
@SuppressWarnings("serial")
public class InterfazElecciones extends JFrame{
    // Atributos

    // Clase principal del mundo.
    private final Urna urna;
    // Atributos de la interfaz
    // Panel con la imagen.
    private final PanelImagen panelImagen;
    // Panel del candidato 1.
    private final PanelCandidato panelCandidato1;
    // Panel del candidato 2.
    private final PanelCandidato panelCandidato2;
    // Panel del candidato 3.
    private final PanelCandidato panelCandidato3;
    // Panel con las opciones.
    private final PanelCandidato panelCandidato4;
    private final PanelOpciones panelOpciones;

    // Constructores
    // Construye la ventana principal de la aplicaciÃ³n y sus paneles.
    public InterfazElecciones( ) {
        setTitle( "Elecciones Estudiantiles CTP AserrÃ­" );
        setSize( 1000, 650 );
        setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );

        urna = new Urna( );

        setLayout( new BorderLayout( ) );

        panelImagen = new PanelImagen( );
        getContentPane( ).add( panelImagen, BorderLayout.NORTH );

        JPanel panelCandidatos = new JPanel( );
        panelCandidatos.setLayout( new GridLayout( 1, 3 ) );
        getContentPane( ).add( panelCandidatos, BorderLayout.CENTER );
        panelCandidato1 = new PanelCandidato( this, 1 );
        panelCandidatos.add( panelCandidato1 );
        panelCandidato2 = new PanelCandidato( this, 2 );
        panelCandidatos.add( panelCandidato2 );
        panelCandidato3 = new PanelCandidato( this, 3 );
        panelCandidatos.add( panelCandidato3 );
        panelCandidato4 = new PanelCandidato( this, 4 );
        panelCandidatos.add( panelCandidato4 );

        // panelUrna = new PanelUrna( );
        panelOpciones = new PanelOpciones( this );
        getContentPane( ).add( panelOpciones, BorderLayout.SOUTH );

        setLocationRelativeTo( null );
        setResizable( false );

        actualizar( );
    }

    // MÃ©todos
    // Registra un voto a un candidato dado el medio de influencia, gÃ©nero y rango de edad.
    // Se registrÃ³ un voto al candidato con el nÃºmero dado.
    // @param pNumeroCandidato NÃºmero del candidato a registrar el voto. pNumeroCandidato > 0 && pNumeroCandidato < 4.
    // @param pMedio Medio de influencia que influenciÃ³ el voto. pMedio == INTERNET || pMedio == RADIO || pMedio == TELEVISION.
    // @param pGenero Gï¿½nero de la persona que registrÃ³ el voto. pGenero == MASCULINO || pGenero == FEMENINO.
    // @param pEdad Rango de edad de la persona que registrÃ³ el voto. pEdad == EDAD_JOVEN || pEdad == EDAD_MEDIA || pEdad == EDAD_MAYOR.
    public void registrarVotoCandidato( int pNumeroCandidato, Medio pMedio, Genero pGenero, Edad pEdad ) {
        urna.registrarVoto( pNumeroCandidato, pEdad, pGenero, pMedio );
        actualizar( );
    }

    // Reinicia la urna.
    public void reiniciarUrna( ){
        urna.reiniciar( );
        actualizar( );
    }

    // Muestra el porcentaje de votos de un candidato dado.
    // @param pNumeroCandidato NÃºmero del candidato del cual se va a mostrar el porcentaje de votos. pNumeroCandidato > 0 && pNumeroCandidato < 4.
    public void mostrarDialogoPorcentajeVotos( int pNumeroCandidato )    {
        JOptionPane.showMessageDialog( this, "Porcentaje de votos: " + formatearValorReal( urna.calcularPorcentajeVotosCandidato( pNumeroCandidato ) ) 
                + " %", "Candidato " + pNumeroCandidato, JOptionPane.INFORMATION_MESSAGE );
    }

    // Retorna el total de votos de la urna.
    public int darTotalVotosUrna( ){
        return urna.calcularTotalVotos( );
    }

    // Muestra el dialogo para votar.
    // @param pNumeroCandidato NÃºmero del candidato a adicionar el voto. pNumeroCandidato > 0 && pNumeroCandidato < 4.
    public void mostrarDialogoVotar( int pNumeroCandidato ) {
        DialogoVotar dialogo = new DialogoVotar( this, pNumeroCandidato );
        dialogo.setVisible( true );
    }

    
    // Muestra el dialogo de estadï¿½sticas de un candidato.
    // @param pNumeroCandidato Nï¿½mero del candidato. pNumeroCandidato > 0 && pNumeroCandidato < 4.
    public void mostrarDialogoEstadisticasCandidato( int pNumeroCandidato ){
        Candidato candidato = urna.buscarCandidato( pNumeroCandidato );

        DialogoEstadisticasCandidatos dialogo = new DialogoEstadisticasCandidatos( this, candidato );
        dialogo.setVisible( true );
    }

    // Muestra el dialogo de estadï¿½sticas totales de las elecciones.
    public void mostrarDialogoEstadisticasTotales( ) {
        int cantMasculino = urna.calcularTotalVotosGeneroMasculino( );
        int cantFemenino = urna.calcularTotalVotosGeneroFemenino( );
        int cantJovenes = urna.darTotalVotosRangoEdad( Edad.EDAD_JOVEN );
        int cantMedia = urna.darTotalVotosRangoEdad( Edad.EDAD_MEDIA );
        int cantMayor = urna.darTotalVotosRangoEdad( Edad.EDAD_MAYOR );
        int totalVotos = urna.calcularTotalVotos( );
        double costoPromedioCampanha = urna.calcularCostoPromedioCampanha( );
        DialogoEstadisticasGenerales dialogo = new DialogoEstadisticasGenerales( this, cantMasculino, 
                cantFemenino, cantJovenes, cantMedia, cantMayor, totalVotos, costoPromedioCampanha );
        dialogo.setVisible( true );
    }

    // Formatea un valor numÃ©rico real.
    // @param pValor Valor numÃ©rico a ser formateado.
    public String formatearValorReal( double pValor ){
        DecimalFormat df = ( DecimalFormat )NumberFormat.getInstance( );
        df.applyPattern( " ###,###.##" );
        df.setMinimumFractionDigits( 2 );
        return df.format( pValor );
    }

    // Actualiza la interfaz. <br>
    // Actualiza todos los paneles.
    private void actualizar( ){
        panelCandidato1.actualizar( urna.darCandidato1( ) );
        panelCandidato2.actualizar( urna.darCandidato2( ) );
        panelCandidato3.actualizar( urna.darCandidato3( ) );
        panelCandidato4.actualizar( urna.darCandidato3( ) );
        // panelUrna.actualizar( urna );
    }

    // Puntos de ExtensiÃ³n
    // MÃ©todo para la extensiï¿½n 1.
    public void reqFuncOpcion1( ){
        String resultado = urna.metodo1( );
        actualizar( );
        JOptionPane.showMessageDialog( this, resultado, "Respuesta", JOptionPane.INFORMATION_MESSAGE );
    }
    
    // MÃ©todo para la extensiï¿½n 2.
    public void reqFuncOpcion2( ){
        String resultado = urna.metodo2( );
        actualizar( );
        JOptionPane.showMessageDialog( this, resultado, "Respuesta", JOptionPane.INFORMATION_MESSAGE );
    }

    // Main
    //Ejecuta la aplicaciÃ³n.
    // @param pArgs ParÃ¡metros de la ejecuciÃ³n. No son necesarios.
    public static void main( String[] pArgs ) {
        try {
            // Unifica la interfaz para Mac y para Windows.
            UIManager.setLookAndFeel( UIManager.getCrossPlatformLookAndFeelClassName( ) );

            InterfazElecciones interfaz = new InterfazElecciones( );
            interfaz.setVisible( true );
        } catch( ClassNotFoundException | IllegalAccessException | InstantiationException | UnsupportedLookAndFeelException e ) {
        }
    }
}
